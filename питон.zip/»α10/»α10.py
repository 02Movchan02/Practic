from tkinter import*
root=Tk()
l1 = Label(text='Имя').grid(row=0, column=0, padx=10)
Name=Entry(width=10)

l2 = Label(text='Пол').grid(row=0, column=1, padx=10)
Gen = Entry(width=5)

l3 = Label(text='Возраст').grid(row=0, column=2, padx=10)
Age=Spinbox(width=10,from_=18, to=100)

l4 = Label(text='Рост').grid(row=0, column=3, padx=10)
Height=Spinbox(width=10,from_=140, to=220)

l5 = Label(text='Вес').grid(row=0, column=4, padx=10)
Weight=Entry(width=10)

Result = Label()
def click():
    Result.grid(row=4, column=0, columnspan=5, pady=10)
    if (Gen.get() == "М"):       
        form = int(Height.get()) - 100 - ((int(Height.get())-150)/4)
        if (form>int(Weight.get())):
            r1=form-int(Weight.get())
            Result['text']="У вас недовес " +str(r1)+ " кг"
        elif (form<int(Weight.get())):
            r2=int(Weight.get())-form
            Result['text']="Ваш вес превышает норму на " +str(r2)+ " кг"
        elif (form==int(Weight.get())):
            Result['text']="У вас идеальный вес"
    elif (Gen.get() == "Ж"):
        form = int(Height.get()) - 100 - ((int(Height.get())-150)/2)
        if (form>int(Weight.get())):
            r1=form-int(Weight.get())
            Result['text']="У вас недовес " +str(r1)+ " кг"
        elif (form<int(Weight.get())):
            r2=int(Weight.get())-form
            Result['text']="Ваш вес превышает норму на " +str(r2)+ " кг"
        elif (form==int(Weight.get())):
            Result['text']="У вас идеальный вес"
rez = Button(text='Подсчитать', command=click).grid(row=3, column=1, columnspan=3, pady=10)

Height.grid(row=1, column=3, padx=10)

Gen.grid(row=1, column=1, padx=10)

Weight.grid(row=1, column=4, padx=10)

Age.grid(row=1, column=2, padx=10)

Name.grid(row=1, column=0, padx=10)


