from tkinter import*
root=Tk()

lab1 = Label(text='Ширина').grid(row=0, column=0,padx=10,pady=5)
lab2 = Label(text='Высота').grid(row=1, column=0,padx=10,pady=5)
class pr:
    def __init__(self):
        self.l1 = Label(width=10, bg="red")
        self.e=Text(width=5, height=1)
        self.b=Button(text='Клик')
        self.l2 = Label(width=10, bg="green")
        self.l1.bind('<Button-3>',self.change)
        self.l2.bind('<Button-3>',self.change2)
        self.b.bind('<Button-1>',self.change3)
        self.l1.grid(row=0, column=1, padx=10,pady=5)
        self.e.grid(row=1, column=2, padx=10,pady=5)
        self.l2.grid(row=1, column=1, padx=10,pady=5)
        self.b.grid(row=0, column=2, padx=10,pady=5)
    def change(self,event):
        self.l1['text']=self.e.get(1.0,END)
    def change2(self,event):
        self.l2['text']=self.e.get(1.0,END)
    def change3(self,event):
        self.e['width']=self.l1['text']
        self.e['height']=self.l2['text']
pr()
root.mainloop()
