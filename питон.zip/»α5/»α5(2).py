fam = input("Введите фамилию отца ")
namef = input("Введите имя отца ")
names = input("Введите имя ребенка ")
sex = input("Введите пол ребенка ")
Dl = len(namef) - 1
if sex == 'М':
    print(fam)
    print(names)
    print(namef[0:Dl] + "евич")
else:
    if sex == 'Ж':
        print(fam)
        print(names)
        print(namef[0:Dl] + "евна")
if namef[-1]!='й':
    if sex=='М':
        print(fam)
        print(names)
        print(namef[:] + "ович")
    else:
        if sex=='Ж':
            print(fam)
            print(names)
            print(namef[:] + "овна")





        
    
    
