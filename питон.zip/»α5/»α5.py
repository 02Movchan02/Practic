slovo = input("Введите слово ")
simv = len(slovo)
if simv > 6:
    print("Третья буква - ",slovo[2])
    print("Шестая буква - ",slovo[5])
else:
    print("Третья буква - ",slovo[2])
    print("В слове только", simv, "букв")
