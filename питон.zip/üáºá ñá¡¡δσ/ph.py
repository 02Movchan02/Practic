from tkinter import*
from tkinter import ttk
from tkinter.filedialog import*
from PIL import Image, ImageTk
import sqlite3 as sql
conn=sql.connect('test.db')
cur=conn.cursor()
root = Tk()
i=1
j=1
images=[]  
def b1(event):
    f=event.widget['text']
    cur.execute("Select userid, Surname, Name, Sex, Birthday, Photo FROM users Where userid=?", [str(f)])
    new=Tk()
    new.geometry('250x20')
    q=Entry(new,width=200)
    one_result=cur.fetchone()
    q.insert(0, one_result)
    q.pack()
    
cur.execute("Select * FROM users;")
rows = cur.fetchall()
for row in rows:
    im=row[5]
    n=row[0]
    img=Image.open(im)
    img.thumbnail((100,100), Image.ANTIALIAS)
    img=ImageTk.PhotoImage(img)
    panel=Label(root, image=img, text=n)
    panel.grid(row=i, column=j)
    panel.bind('<Button-1>', b1)
    images.append(img)
    j+=1
    if j==5:
        i+=1
        j=1
