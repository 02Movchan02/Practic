from tkinter import*
from Create import*
import sqlite3 as sql
conn=sql.connect('test.db')
cur=conn.cursor()
root=Tk()
l1 = Label(text='ID Пользователя').grid(column=3,columnspan=2, row=0)
i = Entry()
l2 = Label(text='Фамилия').grid(column=3,columnspan=2, row=2)
f = Entry()
l3 = Label(text='Имя').grid(column=3,columnspan=2, row=4)
n = Entry()
l4 = Label(text='Пол').grid(column=3,columnspan=2, row=6)
s = Entry()
l5 = Label(text='Год рождения').grid(column=3,columnspan=2, row=8)
y = Entry()
l6 = Label(text='Фото').grid(column=3,columnspan=2, row=10)
p = Entry()
text = Text(width=50, height=10)
def add():
    h1=i.get()
    h2=f.get()
    h3=n.get()
    h4=s.get()
    h5=y.get()
    h6=p.get()
    cur.execute("INSERT INTO users VALUES (?,?,?,?,?,?)",(h1,h2,h3,h4,h5,h6))
    conn.commit()
    cl()
    ref()

def ref():
    text.delete('1.0',END)
    cur.execute("Select userid, Surname, Name, Sex, Birthday FROM users;")
    rows = cur.fetchall()
    for row in rows:
        text.insert(END, '\n')
        text.insert(END, row)
    conn.commit()

def cl():
    i.delete(0, END)
    f.delete(0, END)
    n.delete(0, END)
    s.delete(0, END)
    y.delete(0, END)
    p.delete(0, END)
ref()
b = Button(text='Добавить', command=add)


text.grid(column=3,row=15, padx=10)

b.grid(column=3, row=13, pady=10)
i.grid(column=3, row=1, padx=5)
f.grid(column=3, row=3, padx=5)
n.grid(column=3, row=5, padx=5)
s.grid(column=3, row=7, padx=5)
y.grid(column=3, row=9, padx=5)
p.grid(column=3, row=11, padx=5)

root.mainloop()
