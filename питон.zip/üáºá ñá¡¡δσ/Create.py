import sqlite3 as sql
conn=sql.connect('test.db')
cur=conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS users(
userid INT PRIMARY KEY,
Surname TEXT,
Name TEXT,
Sex TEXT,
Birthday INT,
Photo TEXT);
""");
conn.commit()




