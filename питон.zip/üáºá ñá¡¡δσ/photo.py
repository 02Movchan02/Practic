from tkinter import*
from tkinter import ttk
from tkinter.filedialog import*
from PIL import Image, ImageTk
import sqlite3 as sql
import docx
from tkinter import messagebox as mb
conn=sql.connect('test.db')
cur=conn.cursor()
root = Tk()
treev=ttk.Treeview(root)
treev.pack(side='bottom',pady=10)

verscrlbar = ttk.Scrollbar(root, orient="vertical", command=treev.yview)
verscrlbar.pack(side='left', fill='y')
treev.configure(yscrollcommand=verscrlbar.set)

treev["columns"] = ("1","2","3","4","5")

treev['show']='headings'

treev.column("1", width=90, anchor='c')
treev.column("2", width=90, anchor='se')
treev.column("3", width=90, anchor='se')
treev.column("4", width=90, anchor='se')
treev.column("5", width=90, anchor='se')


treev.heading("1", text="ID Пользователя")
treev.heading("2", text="Фамилия")
treev.heading("3", text="Имя")
treev.heading("4", text="Пол")
treev.heading("5", text="Год рождения")

def select(event):
    cur.execute("Select userid, Surname, Name, Sex, Birthday, Photo FROM users Where userid=?",[str(f)])
    c.delete("all")
    it = treev.selection()[0]
    values=treev.item(it,option="values")
    imya=values[5]
    image=loadi(str(imya))
    c.create_image(100,115,image=image)
    doc = docx.Document()
    doc.add_heading("Пользователь").alignment=1
    par1=doc.add_paragraph(values[0] +' '+values[1] + ' ' + values[2] + ' ' + values[3] + ' '+ values[4]+ ' ' + values[5])
    par1.alignment=1
    doc.add_picture(values[5], width= docx.shared.Cm(10))
    #pt =os.getcwd()+'\Word\'
    #pat = pt + values[1]+'docx'
    #with open(pat, 'w') as pat:
    doc.save(values[1]+'.docx')
    mb.showinfo("Информация", "Файл "+values[1]+" был создан")
    root.mainloop()
    
def loadi(name):
    img = Image.open(name)
    img.thumbnail((200,200), Image.ANTIALIAS)
    return ImageTk.PhotoImage(img)

def view():
    cur.execute("Select userid, Surname, Name, Sex, Birthday, Photo FROM users;")
    count = cur.fetchall()
    for i in count:
        treev.insert("",'end', values=i)
    conn.commit()
    
treev.bind('<<TreeviewSelect>>', select)

l1 = Label(text='ID Пользователя')
i1 = Entry()
l2 = Label(text='Фамилия')
f = Entry()
l3 = Label(text='Имя')
n = Entry()
l4 = Label(text='Пол')
s = Entry()
l5 = Label(text='Год рождения')
y = Entry()
c = Canvas()
def add():
    treev.delete(*treev.get_children())
    imagefile = askopenfile(filetypes=[('JPG images', '.jpg'), ('PNG images', '.png'), ('JPEG images', '.jpg')])
    full_name=os.path.basename(str(imagefile))
    s1=os.path.splitext(full_name)[0]
    s2=os.path.splitext(full_name)[1]
    s=s2.find( "'" )
    h6=s1+s2[0:s]
    h1=i.get()
    h2=f.get()
    h3=n.get()
    h4=s.get()
    h5=y.get()
    cur.execute("INSERT INTO users VALUES (?,?,?,?,?,?)",(h1,h2,h3,h4,h5,h6))
    conn.commit()
    cl()

def cl():
    i.delete(0, END)
    f.delete(0, END)
    n.delete(0, END)
    s.delete(0, END)
    y.delete(0, END)
view()
b = Button(text='Добавить', command=add)

l1.pack(side='top')
i1.pack(side='top')
l2.pack(side='top')
f.pack(side='top')
l3.pack(side='top')
n.pack(side='top')
l4.pack(side='top')
s.pack(side='top')
l5.pack(side='top')
y.pack(side='top')
b.pack(side='top',pady=10)
c.pack(side='top')
