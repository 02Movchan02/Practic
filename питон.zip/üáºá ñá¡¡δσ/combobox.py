from tkinter import*
from tkinter import ttk
import sqlite3 as sql
conn=sql.connect('test.db')
cur=conn.cursor()
root=Tk()

treev=ttk.Treeview(root)
treev.pack(side='right')

verscrlbar = ttk.Scrollbar(root, orient="vertical", command=treev.yview)
verscrlbar.pack(side='left', fill='y')
treev.configure(yscrollcommand=verscrlbar.set)

treev["columns"] = ("1","2","3","4","5")

treev['show']='headings'

treev.column("1", width=90, anchor='c')
treev.column("2", width=90, anchor='se')
treev.column("3", width=90, anchor='se')
treev.column("4", width=90, anchor='se')
treev.column("5", width=90, anchor='se')

treev.heading("1", text="ID Пользователя")
treev.heading("2", text="Фамилия")
treev.heading("3", text="Имя")
treev.heading("4", text="Пол")
treev.heading("5", text="Год рождения")

combo=ttk.Combobox(values=["Год рождения", "Возраст"])
combo.pack(side='right')

def view():
    treev.heading("5", text="Год рождения")
    cur.execute("Select userid, Surname, Name, Sex, Birthday FROM users;")
    count = cur.fetchall()
    for i in count:
        treev.insert("",'end', values=i)
    conn.commit()
view()

def click(event):
    treev.delete(*treev.get_children())
    if (combo.get()=='Год рождения'):
        view()
    elif (combo.get()=='Возраст'):
        cur.execute("Select userid, Surname, Name, Sex, (2021-Birthday) FROM users;")
        treev.heading("5", text="Возраст")
        count = cur.fetchall()
        for i in count:
            treev.insert("",'end', values=i)
        conn.commit()
        
combo.bind('<<ComboboxSelected>>', click)
    
root.mainloop()
