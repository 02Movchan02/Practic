from tkinter import*
from tkinter import ttk
import sqlite3 as sql
conn=sql.connect('test.db')
cur=conn.cursor()
root = Tk()
treev=ttk.Treeview(root)
treev.pack(side='right')

verscrlbar = ttk.Scrollbar(root, orient="vertical", command=treev.yview)
verscrlbar.pack(side='left', fill='y')
treev.configure(yscrollcommand=verscrlbar.set)

treev["columns"] = ("1","2","3","4","5","6")

treev['show']='headings'

treev.column("1", width=90, anchor='c')
treev.column("2", width=90, anchor='se')
treev.column("3", width=90, anchor='se')
treev.column("4", width=90, anchor='se')
treev.column("5", width=90, anchor='se')
treev.column("6", width=90, anchor='se')

treev.heading("1", text="ID Пользователя")
treev.heading("2", text="Фамилия")
treev.heading("3", text="Имя")
treev.heading("4", text="Пол")
treev.heading("5", text="Год рождения")
treev.heading("6", text="Фото")

values=0

cur.execute("Select * FROM users;")
count = cur.fetchall()
for i in count:
    treev.insert("",'end', values=i)
conn.commit()
def select(event):
    global values
    it = treev.selection()[0]
    values=treev.item(it,option="values")

    treev.delete(*treev.get_children())
    cur.execute("DELETE FROM users WHERE userid =?", [values[0]])
    conn.commit()

    cur.execute("Select * FROM users;")
    count = cur.fetchall()
    for i in count:
        treev.insert("",'end', values=i)
    conn.commit()
treev.bind('<<TreeviewSelect>>', select)



