from tkinter import*
root=Tk()
root.geometry("600x800")
f_left = Frame()
f_right = Frame()
clicks = 0
def click():
    global clicks
    if clicks == 0:
        f_right.pack(side=RIGHT, anchor = S, padx=10, pady=10)
        clicks = 1
    else:
        if clicks == 1:
            f_right.pack(side=RIGHT, anchor = N, padx=10, pady=10)
            clicks = 0
b1 = Button(f_left, text="Кнопка", command=click)
l1 = Label(f_right, text="метка")
f_left.pack(side=LEFT, anchor=N, padx=10, pady=10)
b1.pack()
f_right.pack(side=RIGHT, anchor = N, padx=10, pady=10)
l1.pack()
root.mainloop()
