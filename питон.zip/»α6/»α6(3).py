﻿from tkinter import*
root=Tk()
f_center = Frame()
f_bot= Frame()
def click1():
    global slovo
    global DL
    slovo = input("Введите слово ")
    DL = len(slovo)
    e1.insert(0, slovo)
def click2():
    global slovo
    global DL
    slovo=slovo[1:DL] + slovo[0]
    e1.delete(0,END)
    e1.insert(0, slovo)
b1 = Button(f_center, text="кнопка 1", command = click1)
b2 = Button(f_center, text="кнопка 2", command = click2)
f_center.pack(padx=10, pady=10)
f_bot.pack(padx=10, pady=10)
b1.pack(side=LEFT, padx=10)
b2.pack(side=LEFT, padx=10)
e1 = Entry(f_bot, width=25)
e1.pack()
