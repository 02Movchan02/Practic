from tkinter import*
clicks=0

root = Tk()
root.geometry("600x800")
def color():
    col = input("Введите код цвета ")
    l1['bg']=col
    l1['text']=str(col)
def jm():
    global clicks
    global jmi
    j = "Ж"+b2['text']
    clicks+=1
    b2['text']=j+"И"
l1 = Label(text="123")
l1.pack()
b1=Button(text="Цвет", command=color)
b1.pack()
b2=Button(text="ЖМИ", command=jm)
b2.pack()
root.mainloop()

    
