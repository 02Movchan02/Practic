from tkinter import*
root=Tk()
e=Entry()
b=Button(text='КЛИК')
l=0
la=Label(text='Введите падеж')
e1=Entry()
def click():
    slovo = e.get()
    l=len(e.get())
    if (slovo[-1] == 'а'):
        if (e1.get() == 'И'):
            slovo=slovo
        else:
                if (e1.get()=='Р'):
                    slovo=slovo[0:l-1] + 'ы'
                else:
                        if (e1.get()=='Д'):
                            slovo=slovo[0:l-1] + 'е'
                        else:
                                if (e1.get()=='В'):
                                    slovo=slovo[0:l-1] + 'у'
                                else:
                                    if (e1.get()=='Т'):
                                        slovo=slovo[0:l-1] + 'ой'
                                    else:
                                        if (e1.get()=='П'):
                                            slovo=slovo[0:l-1] + 'е'
    else:
        if(slovo[-1]!='а'):
            if(slovo[-1]!='я'):
                if (e1.get() == 'И'):
                 slovo=slovo
                else:
                    if (e1.get()=='Р'):
                        slovo=slovo[0:l] + 'а'
                    else:
                        if (e1.get()=='Д'):
                            slovo=slovo[0:l] + 'у'
                        else:
                            if (e1.get()=='В'):
                                 slovo=slovo
                            else:
                                if (e1.get()=='Т'):
                                     slovo=slovo[0:l] + 'ом'
                                else:
                                    if (e1.get()=='П'):
                                        slovo=slovo[0:l] + 'е'
            else:
                if(slovo[-1]=='я'):
                    if (e1.get() == 'И'):
                         slovo=slovo
                    else:
                         if (e1.get()=='Р'):
                            slovo=slovo[0:l-1] + 'и'
                         else:
                            if (e1.get()=='Д'):
                                slovo=slovo[0:l-1] + 'е'
                            else:
                                if (e1.get()=='В'):
                                    slovo=slovo[0:l-1] + 'ю'
                                else:
                                    if (e1.get()=='Т'):
                                        slovo=slovo[0:l-1] + 'ёй'
                                    else:
                                        if (e1.get()=='П'):
                                            slovo=slovo[0:l-1] + 'е'
                    
    e.delete(0,END)
    e.insert(0,slovo)
    la.pack()
    e1.pack()
e.pack()
b.config(command=click)
b.pack()
root.mainloop()
