from tkinter import*
root=Tk()
root.geometry('600x200')
e=Entry()
e1=Entry()
l=0
b=Button(text='Клац')
def slovo():
    e1.delete(0,END)
    global l
    l=len(e.get())
    for i in range(0,l):        
        s=e.get() [i]   
        e1.insert(0,s)
e.pack(padx=10, pady=20)
b.config(command=slovo)
b.pack()
e1.pack(padx=10,pady=20)
root.mainloop()
    
