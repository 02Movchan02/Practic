Time = 0.25
Temp = 180
