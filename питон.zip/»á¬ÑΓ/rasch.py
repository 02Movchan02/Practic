from first import Masl, Egg, Myk
from Time_Temp import*
from price import*
if int(Masl)>100:
    kolvo = (int(Masl) * 25) /100
elif int(Egg)>1:
    kolvo = 25*int(Egg)
elif int(Myk)>350:
    kolvo = (int(Myk)*25)/350
t = round((kolvo*Time)/25,2)
Tem = Temp
pr = kolvo * 20


