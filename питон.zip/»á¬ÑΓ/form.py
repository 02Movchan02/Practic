from tkinter import*
from rasch import*
root=Tk()
root.geometry("400x100")
kol = Label(text="Количество печенья: "+str(round(kolvo,0)))
tim = Label(text="Времени займет (в часах): "+str(t))
temp = Label(text="Запекать при температуре: " +str(Tem))
cen = Label(text="Стоимость (в рублях): " + str(round(pr,1)))
kol.pack()
tim.pack()
temp.pack()
cen.pack()
root.mainloop
