from tkinter import*

def motion():
    global x,y
    c.move("g", x/10,y/10)
    if c.coords("g")[1] < 350:
        if c.coords("g")[2]<400:
            root.after(50, motion)
root=Tk()
c = Canvas(width=700, height=500)
c.pack()
c.create_oval(10,20,70,80,tag="sun", fill="yellow")
c.create_line(40,15,40,2,tag="sun")
c.create_line(20,25,10,12,tag="sun")
c.create_line(40,85,42,100,tag="sun")
c.create_line(70,65,82,70,tag="sun")
c.create_line(10,65,0,70,tag="sun")
c.create_line(70,30,80,20,tag="sun")

c.create_oval(50,150, 120,230, fill="green", tag="g")
c.create_oval(100,150, 170,230, fill="darkblue", tag="g")
c.create_oval(150,150, 220,230, fill="pink", tag="g")
c.create_oval(200,150, 270,230, fill="brown", tag="g")
c.create_oval(250,150, 320,230, fill="lightblue", tag="g")
c.create_oval(230,70, 320,160, fill="pink", tag="g")
c.create_oval(250,100, 260,120, fill="black", tag="g")
c.create_oval(290,100, 300,120, fill="black", tag="g")
c.create_arc(220, 10, 270, 135, start=0,style=ARC, extent=140, tag="g")
c.create_arc(280, 10, 290, 135, start=0,style=ARC, extent=60, tag="g")
c.create_arc(250, 140, 300, 130, start=0,style=ARC, extent=-140, tag="g")

c.create_line(75,230,75,250,tag="g", width=5)
c.create_oval(70,245,85,255, fill="black",tag="g")
c.create_line(95,230,95,250,tag="g", width=5)
c.create_oval(90,245,105,255, fill="black",tag="g")


c.create_line(130,230,130,250,tag="g", width=5)
c.create_oval(125,245,140,255, fill="black",tag="g")
c.create_line(145,225,150,250,tag="g", width=5)
c.create_oval(145,245,160,255, fill="black",tag="g")

c.create_line(180,230,181,250,tag="g", width=5)
c.create_oval(178,245,192,255, fill="black",tag="g")
c.create_line(195,229,200,250,tag="g", width=5)
c.create_oval(195,245,210,255, fill="black",tag="g")

c.create_line(225,227,225,250,tag="g", width=5)
c.create_oval(223,245,240,255, fill="black",tag="g")
c.create_line(245,229,246,250,tag="g", width=5)
c.create_oval(245,245,260,255, fill="black",tag="g")

c.create_line(275,228,277,250,tag="g", width=5)
c.create_oval(275,245,290,255, fill="black",tag="g")
c.create_line(295,229,295,250,tag="g", width=5)
c.create_oval(294,245,310,255, fill="black",tag="g")
x=0
y=0
def oval_func(event):
    global x,y
    x=event.x_root
    y=event.y_root
    motion()
c.bind('<Button-1>', oval_func)
root.mainloop()
