from tkinter import*
root=Tk()
root.geometry('600x600')
rez=0
v1=DoubleVar()
v2=DoubleVar()
v3=DoubleVar()
v4=DoubleVar()
v5=DoubleVar()
v6=DoubleVar()
v7=DoubleVar()

l1=Label(text='1. Первый цвет радуги').place(relx=0)
r1=Radiobutton(text='Зеленый', variable=v1, value=0)
r2=Radiobutton(text='Красный', variable=v1, value=1.4)
r3=Radiobutton(text='Синий', variable=v1, value=1)

l2=Label(text='2. Сколько будет 2+5?').place(relx=0,rely=0.2)
r4=Radiobutton(text='5', variable=v2, value=0)
r5=Radiobutton(text='25', variable=v2, value=1)
r6=Radiobutton(text='7', variable=v2, value=1.4)

l3=Label(text='3. 2^8, сколько будет?').place(relx=0,rely=0.4)
r7=Radiobutton(text='256', variable=v3, value=1.4)
r8=Radiobutton(text='128', variable=v3, value=1)
r9=Radiobutton(text='512', variable=v3, value=0)

l4=Label(text='4. Бренд с надкусанным яблоком?').place(relx=0,rely=0.6)
r10=Radiobutton(text='Android', variable=v4, value=0)
r11=Radiobutton(text='Apple', variable=v4, value=1.4)
r12=Radiobutton(text='Microsoft', variable=v4, value=1)

l5=Label(text='5. На лого этого месседжера бумажный самолётик').place(relx=0.5)
r13=Radiobutton(text='VK', variable=v5, value=0)
r14=Radiobutton(text='Whats App', variable=v5, value=1)
r15=Radiobutton(text='Telegram', variable=v5, value=1.4)

l6=Label(text='6. Животное в полоску, по которой переходят').place(relx=0.5, rely=0.2)
r16=Radiobutton(text='Ягуар', variable=v6, value=0)
r17=Radiobutton(text='Конь', variable=v6, value=1)
r18=Radiobutton(text='Зебра', variable=v6, value=1.4)

l7=Label(text='7. Чьи штаны во все стороны равны?').place(relx=0.5, rely=0.4)
r19=Radiobutton(text='Пифагоровы', variable=v7, value=1.4)
r20=Radiobutton(text='Платоновы', variable=v7, value=0)
r21=Radiobutton(text='Диагеновы', variable=v7, value=1)


def click():
    global rez
    if v1.get()==1.4:
        rez=rez+0.7
        r2['bg']='green'
    else:
        rez=rez+0
        r2['bg']='green'
        r1['bg']='red'
        r3['bg']='red'
    if v2.get()==1.4:
        rez=rez+0.7
        r6['bg']='green'
    else:
        rez=rez+0
        r6['bg']='green'
        r5['bg']='red'
        r4['bg']='red'
    if v3.get()==1.4:
        rez=rez+0.7
        r7['bg']='green'
    else:
        rez=rez+0
        r7['bg']='green'
        r8['bg']='red'
        r9['bg']='red'
    if v4.get()==1.4:
        rez=rez+0.7
        r11['bg']='green'
    else:
        rez=rez+0
        r11['bg']='green'
        r10['bg']='red'
        r12['bg']='red'
    if v5.get()==1.4:
        rez=rez+0.7
        r15['bg']='green'
    else:
        rez=rez+0
        r15['bg']='green'
        r14['bg']='red'
        r13['bg']='red'
    if v6.get()==1.4:
        rez=rez+0.7
        r18['bg']='green'
    else:
        rez=rez+0
        r18['bg']='green'
        r17['bg']='red'
        r16['bg']='red'
    if v7.get()==1.4:
        rez=rez+0.8
        r19['bg']='green'
    else:
        rez=rez+0
        r19['bg']='green'
        r20['bg']='red'
        r21['bg']='red'
    lr = Label(text=rez).place(relx=0.4, rely=0.8)
r1.place(relx=0, rely=0.05)
r2.place(relx=0, rely=0.1)
r3.place(relx=0, rely=0.15)
r4.place(relx=0, rely=0.25)
r5.place(relx=0, rely=0.3)
r6.place(relx=0, rely=0.35)
r7.place(relx=0, rely=0.45)
r8.place(relx=0, rely=0.5)
r9.place(relx=0, rely=0.55)
r10.place(relx=0, rely=0.65)
r11.place(relx=0, rely=0.7)
r12.place(relx=0, rely=0.75)
r13.place(relx=0.5, rely=0.05)
r14.place(relx=0.5, rely=0.1)
r15.place(relx=0.5, rely=0.15)
r16.place(relx=0.5, rely=0.25)
r17.place(relx=0.5, rely=0.3)
r18.place(relx=0.5, rely=0.35)
r19.place(relx=0.5, rely=0.45)
r20.place(relx=0.5, rely=0.5)
r21.place(relx=0.5, rely=0.55)
b=Button(text='Ответить', command=click).place(relx=0.4, rely=0.7)
root.mainloop
