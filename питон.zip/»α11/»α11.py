from tkinter import*
root=Tk()
click=0
lb = Listbox()
lb.grid(row=0, columnspan=2)
txt=""
def click1():
    global txt
    txt=input("Введите значение: ")
    lb.insert(END,txt)
def click2():
    txt = lb.get(END)
    l = len(txt)//2
    lend = len(txt)
    s=txt[l:lend]
    lb.insert(END, s)
b1=Button(text='click', command=click1).grid(row=1, column=0)
b2=Button(text='клик', command=click2).grid(row=1, column=1)

