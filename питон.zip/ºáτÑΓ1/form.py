from tkinter import*
from tkinter import ttk
import sqlite3 as sql
from Create import*
conn=sql.connect('PRODUKTY.db')
cur=conn.cursor()
root=Tk()
root.geometry('600x700')
treev=ttk.Treeview()

def cl():
    treev.delete(*treev.get_children())
    name.delete(0,END)
    kol.delete(0,END)
    price.delete(0,END)
    ves.delete(0,END)
    pos.delete(0,END)

def view():
    cur.execute("SELECT Номер_Товара, Наименование, Цена, Поставщик FROM Товар")
    count = cur.fetchall()
    for i in count:
        treev.insert("", 'end', values=i)
    conn.commit()

def add():
    h1=name.get()
    h2=kol.get()
    h3=price.get()
    h4=ves.get()
    h5=pos.get()
    cur.execute("INSERT INTO Товар (Наименование, Количество, Цена, Вес, Поставщик) VALUES (?,?,?,?,?)",(h1,h2,h3,h4,h5))
    conn.commit()
    cl()
    view()

def dl(event):
    it=treev.selection()[0]
    values=treev.item(it,option="values")
    cur.execute("DELETE FROM Товар WHERE Цена = ?", [values[2]])
    conn.commit()
    cl()
    view()
    
treev.bind('<<TreeviewSelect>>', dl)

verscrlbar = ttk.Scrollbar(root, orient="vertical", command = treev.yview)
verscrlbar.pack(side='left', fill='y')
treev.configure(yscrollcommand=verscrlbar.set)

treev["columns"] = ("1", "2","3","4","5","6")
treev['show']='headings'

treev.column("1", width=90, anchor='c')
treev.column("2", width=90, anchor='se')
treev.column("3", width=90, anchor='se')
treev.column("4", width=90, anchor='se')

treev.heading("1", text="Номер_товара")
treev.heading("2", text="Наименование")
treev.heading("3", text="Цена")
treev.heading("4", text="Поставщик")

l1=Label(text="Наименование").place(relx=0.43, rely=0)
name = Entry()
l2 = Label(text="Количество").place(relx=0.43, rely=0.1)
kol = Entry()
l3 = Label(text="Цена").place(relx=0.43, rely=0.2)
price = Entry()
l4 = Label(text="Вес").place(relx=0.43, rely=0.3)
ves = Entry()
l5 = Label(text="Поставщик").place(relx=0.43, rely=0.4)
pos = Entry()

b = Button(text="Добавить", command=add)

treev.pack(side='bottom')

name.place(relx=0.4, rely=0.05)
kol.place(relx=0.4, rely=0.15)
price.place(relx=0.4, rely=0.25)
ves.place(relx=0.4, rely=0.35)
pos.place(relx=0.4, rely=0.45)

b.place(relx=0.45, rely=0.5)

view()
root.mainloop()


