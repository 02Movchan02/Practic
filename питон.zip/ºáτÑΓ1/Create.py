import sqlite3 as sql
conn = sql.connect('PRODUKTY.db')
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS Товар(
Номер_Товара INTEGER PRIMARY KEY AUTOINCREMENT,
Наименование TEXT,
Количество INT,
Цена REAL,
Вес REAL,
Поставщик TEXT);
""")
conn.commit()
