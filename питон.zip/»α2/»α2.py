from tkinter import*
clicks=0
name="Дима"
def click_button():
    global clicks
    global name 
    name=name+name[clicks]
    clicks+=1
    btn['text']=name
def clicks_button2():
    f=str(input("Введите Фамилию "))
    n=str(input("Введите Имя "))
    age=int(input("Введите возраст "))
    age = 2020-age
    print(f, n,"*",age, "года рождения")
root=Tk()
root.title("Рябов")
root.geometry("800x600")
btn=Button(text=name, background="#555", foreground="#ccc", height=10, width=15,command=click_button)
btn2=Button(text="Два", command=clicks_button2)
btn.pack()
btn2.pack()
root.mainloop()

