import os
from tkinter import filedialog as fd
from tkinter import*
l1 = Label(text='Фамилия:').grid(row=0,column=0, padx=10, pady=5)
l2 = Label(text='Имя:').grid(row=1,column=0, padx=10, pady=5)
l3 = Label(text='Отчество:').grid(row=2,column=0, padx=10, pady=5)
l4 = Label(text='Возраст:').grid(row=3,column=0, padx=10, pady=5)
F = Entry()
I = Entry()
O = Entry()
A = Entry()

def click():
    file_name = fd.askopenfilename()
    full_name = os.path.basename(str(file_name))
    file_name = fd.asksaveasfilename(filetypes=(("TXT files", "*.txt"),("All files", "*.*")))
    f = open(file_name, 'w')
    f.write("Фамилия: " + F.get()+"\n"+ "Имя: " + I.get()+"\n"+"Отчество: " + O.get()+"\n"+"Возраст: "+A.get())
F.grid(row=0, column=1, padx=10,pady=5)
I.grid(row=1, column=1, padx=10,pady=5)
O.grid(row=2, column=1, padx=10,pady=5)
A.grid(row=3, column=1, padx=10,pady=5)
B = Button(text='Открыть файл', command=click).grid(row=4, columnspan=2, padx=10,pady=5)
