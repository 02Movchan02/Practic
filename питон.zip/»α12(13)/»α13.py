names = [["Батон де Гралье", 55], ["Финшампан", 101], ["Крем де ризьен",155], ["Буль-де-гом",77], ["Крем де нуазон",204]]
names.sort()
for item in names:
    print(item)
q = input("Хотите добавить данные? ")
while q == "Да":
    if (q=="Да"):
        n = input("Введите название конфет ")
        p = input("Введите стоимость конфет ")
        name = list()
        name.append(n)
        name.append(int(p))
        names.append(name)
        names.sort()
        for item in names:
            print(item)
    elif (q=="Нет"):
        names.sort()
        for item in names:
            print(item)
    q = input("Хотите добавить данные? ")
