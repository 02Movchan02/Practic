from tkinter import* 
from PIL import Image, ImageTk 
root=Tk()
c1=Canvas(root, width=100,height=100) 
c1.grid()

c2=Canvas(root,width=100,height=100)
c2.grid(column=1, row=0)

c3=Canvas(root,width=100, height=100)
c3.grid(row=1,column=0)

c4=Canvas(root,width=100,height=100)
c4.grid(row=1,column=1)

img=Image.open ('222.jpg')
img = ImageTk.PhotoImage(img)

img2=Image.open ('222.jpg')
img2 = img2.convert('L')
img2 = ImageTk.PhotoImage(img2)

img3=Image.open ('222.jpg')
img3=img3.resize((50,80),Image.ANTIALIAS)
img3 = ImageTk.PhotoImage(img3)

img4=Image.open ('222.jpg')
img4.thumbnail((200,100),Image.ANTIALIAS)
img4 = ImageTk.PhotoImage(img4)

imagesprite=c1.create_image(0,0,image=img)
imagesprite=c2.create_image(100,100,image=img2)
imagesprite=c3.create_image(50,50,image=img3)
imagesprite=c4.create_image(100,100,image=img4)
root.mainloop() 
